export const ROUTES = {
    HOME: "/",
    DETAILS: "/details",
  };
  