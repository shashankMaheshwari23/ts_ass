export const baseURL = "https://pokeapi.co/api/v2";
export const LIMIT = 12;
export const SEARCH_SLICED = 30;
