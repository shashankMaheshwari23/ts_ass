import { createContext, Dispatch } from "react";
import { ActionType, StateType } from "../../store/reducers/reducer";
import { Pokemon } from "../../store/reducers/reducer";

// Define the context type based on the initial state

export interface PokemonContextType {
  state: StateType;
  dispatch: Dispatch<ActionType>;
  getPokemonData: (isReset?: boolean) => Promise<void>;
  getPokemonDetailsListByUrl: (results: Pokemon[]) => Promise<any[]>;
  setAppLoading: (loading: boolean) => void;
}

const defaultPokemonContextValue: PokemonContextType = {
  state: {
    pokemonsList: [],
    allPokemonsList: [],
    pokemonSelectedId: null,
    pokemonData: null,
    isLoading: false,
    isLoadMoreInprogress: false,
    pokemonsTypes: [],
    pokemonGenderList: []
  },
  dispatch: () => { /* no-op */ },
  getPokemonData: async () => { /* no-op */ },
  getPokemonDetailsListByUrl: async () => [],
  setAppLoading: () => { /* no-op */ },
};
const PokemonContext = createContext<PokemonContextType>(defaultPokemonContextValue);

export default PokemonContext;
