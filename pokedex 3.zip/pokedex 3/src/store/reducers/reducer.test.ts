import { reducer, initialState, StateType, ActionType } from './reducer';

import { cardData } from '../../components/pokemonCard/pokemonCardMock.data';

describe('Pokemon Reducer', () => {
  it('should set the Pokémon list', () => {
    const action: ActionType = {
      type: 'ACTIONS.SET_POKEMON_LIST',
      payload: [{ name: 'Pikachu' }, { name: 'Bulbasaur' }],
    };

    const state = reducer(initialState, action);
    expect(state.pokemonsList).toEqual(action.payload);
  });

  it('should append to the existing Pokémon list', () => {
    const prevState: StateType = {
      ...initialState,
      pokemonsList: [cardData],
    };

    const action: ActionType = {
      type: 'ACTIONS.SET_POKEMON_LIST',
      payload: [{ name: 'Squirtle' }],
    };

    const state = reducer(prevState, action);
    expect(state.pokemonsList).toEqual([
      cardData,
      { name: 'Squirtle' },
    ]);
  });

  it('should set all Pokémon list', () => {
    const action: ActionType = {
      type: 'ACTIONS.SET_ALL_POKEMON_LIST',
      payload: [{ name: 'Mewtwo' }],
    };

    const state = reducer(initialState, action);
    expect(state.allPokemonsList).toEqual(action.payload);
  });

  it('should set loading state', () => {
    const action: ActionType = {
      type: 'ACTIONS.SET_API_CALL_INPROGRESS',
      payload: false,
    };

    const state = reducer(initialState, action);
    expect(state.isLoading).toBe(false);
  });

  it('should reset Pokémon data', () => {
    const prevState: StateType = {
      ...initialState,
      pokemonData: cardData,
    };

    const action: ActionType = {
      type: 'ACTIONS.RESET_POKEMON_DATA',
    };

    const state = reducer(prevState, action);
    expect(state.pokemonData).toBeNull();
  });

  it('should return the same state for unknown action type', () => {
    const action = {
      type: 'UNKNOWN_ACTION',
      payload: {},
    } as unknown as ActionType;

    const state = reducer(initialState, action);
    expect(state).toBe(initialState);
  });
});
