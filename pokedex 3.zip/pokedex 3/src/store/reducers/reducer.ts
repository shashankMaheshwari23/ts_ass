// import * as ACTIONS from "../../store/actions/pokemonAction";

export interface Pokemon {
  id: number;
  name: string;
  base_experience: number;
  height: number;
  weight: number;
  order: number;
  is_default: boolean;
  abilities: Ability[];
  forms: NamedAPIResource[];
  types: TypeSlot[];
  sprites: Sprites;
  stats?: any;
  url?: string;
  // Add more fields as needed
}

export interface Ability {
  ability: NamedAPIResource;
  is_hidden: boolean;
  slot: number;
}

export interface NamedAPIResource {
  name: string;
  url: string;
}

export interface TypeSlot {
  slot: number;
  type: NamedAPIResource;
}

export interface Sprites {
  front_default: string | null;
  front_shiny?: string | null;
  front_female?: string | null;
  front_shiny_female?: string | null;
  back_default?: string | null;
  back_shiny?: string | null;
  back_female?: string | null;
  back_shiny_female?: string | null;
  other?: {
    dream_world?: {
      front_default: string | null;
      front_female?: string | null;
    };
    home?: {
      front_default: string | null;
      front_female?: string | null;
      front_shiny?: string | null;
      front_shiny_female?: string | null;
    };
    'official-artwork'?: {
      front_default: string | null;
      front_shiny?: string | null;
    };
  };
  versions?: {
    [generation: string]: {
      [version: string]: Partial<Sprites>;
    };
  };
}

export interface StateType {
    pokemonsList: Pokemon[] | [];
    allPokemonsList: Pokemon[] | [];
    pokemonSelectedId: number | null;
    pokemonData: Pokemon | null;
    isLoading: boolean;
    isLoadMoreInprogress: boolean;
    pokemonsTypes: any[];
    pokemonGenderList: any[];
  }
  
  export const initialState: StateType = {
    pokemonsList: [],
    allPokemonsList: [],
    pokemonSelectedId: null,
    pokemonData: null,
    isLoading: true,
    isLoadMoreInprogress: false,
    pokemonsTypes: [],
    pokemonGenderList: []
  };

  export type ActionType =
  | { type: "ACTIONS.SET_POKEMON_LIST"; payload: any[] }
  | { type: "ACTIONS.SET_ALL_POKEMON_LIST"; payload: any[] }
  | { type: "ACTIONS.SET_FILTERED_POKEMON_LIST"; payload: any[] }
  | { type: "ACTIONS.SET_POKEMON_TYPE"; payload: any[] }
  | { type: "ACTIONS.SET_POKEMON_GENDER_LIST"; payload: any[] }
  | { type: "ACTIONS.SET_API_CALL_INPROGRESS"; payload: boolean }
  | { type: "ACTIONS.SET_LOAD_MORE_API_CALL_INPROGRESS"; payload: boolean }
  | { type: "ACTIONS.SET_POKEMON_BY_ID"; payload: any }
  | { type: "ACTIONS.RESET_POKEMON_DATA" }
  | { type: "ACTIONS.SET_POKEMON_ID"; payload: number };


export const reducer = (state: StateType, action: ActionType) => {

    switch (action.type) {
        case "ACTIONS.SET_POKEMON_LIST":
            return {
                ...state, pokemonsList: [...state.pokemonsList, ...action.payload]
            };
        case "ACTIONS.SET_ALL_POKEMON_LIST":
            return {
                ...state, allPokemonsList: action.payload
            };
        case "ACTIONS.SET_FILTERED_POKEMON_LIST":
            return {
                ...state, pokemonsList: action.payload
            };
        case "ACTIONS.SET_POKEMON_TYPE":
            return {
                ...state, pokemonsTypes: action.payload
            };

        case "ACTIONS.SET_POKEMON_GENDER_LIST":
            return {
                ...state, pokemonGenderList: action.payload
            };

        case "ACTIONS.SET_API_CALL_INPROGRESS":
            return {
                ...state, isLoading: action.payload
            };
        case "ACTIONS.SET_LOAD_MORE_API_CALL_INPROGRESS":
            return {
                ...state, isLoadMoreInprogress: action.payload
            };

        case "ACTIONS.SET_POKEMON_BY_ID":
            return {
                ...state, pokemonData: action.payload
            };
        case "ACTIONS.RESET_POKEMON_DATA":
            return {
                ...state, pokemonData: null
            };
        case "ACTIONS.SET_POKEMON_ID":
            return {
                ...state, pokemonSelectedId: action.payload
            };

        default:
            return state

    }

}