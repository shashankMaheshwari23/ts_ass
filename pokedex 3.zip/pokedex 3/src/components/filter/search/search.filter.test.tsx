import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import SearchFilter from './search.filter';

describe('SearchFilter Component', () => {
  const mockOnChangeHandler = jest.fn();

  const renderComponent = (props = {}) =>
    render(
      <SearchFilter
        placeholder="Search..."
        inputClass="test-input-class"
        onChangeHandler={mockOnChangeHandler}
        label="Search By"
        {...props}
      />
    );

  test('renders input with placeholder', () => {
    renderComponent();
    expect(screen.getByPlaceholderText('Search...')).toBeInTheDocument();
  });

  test('renders label correctly', () => {
    renderComponent();
    expect(screen.getByText('Search By')).toBeInTheDocument();
  });

  test('calls onChangeHandler on input change', () => {
    renderComponent();
    const inputElement = screen.getByPlaceholderText('Search...');
    fireEvent.change(inputElement, { target: { value: 'pikachu' } });
    expect(mockOnChangeHandler).toBeCalled();
  });

  test('applies custom input class', () => {
    renderComponent();
    const inputElement = screen.getByPlaceholderText('Search...');
    expect(inputElement).toHaveClass('test-input-class');
  });

  test('renders search icon button', () => {
    renderComponent();
    expect(screen.getByRole('button')).toBeInTheDocument();
  });
});
