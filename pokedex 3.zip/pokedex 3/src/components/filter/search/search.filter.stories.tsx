import React from 'react';
import { Meta, StoryFn } from '@storybook/react';
import SearchFilter from './search.filter';

export default {
  title: 'Components/SearchFilter',
  component: SearchFilter,
  argTypes: {
    onChangeHandler: { action: 'changed' },
  },
} as Meta;

const Template: StoryFn<{
  placeholder?: string;
  inputClass?: string;
  label?: string;
  onChangeHandler: (value: string) => void;
}> = (args) => <SearchFilter {...args} />;

export const Default = Template.bind({});
Default.args = {
  placeholder: 'Search...',
  inputClass: 'custom-input-class',
  label: 'Search Label',
};
