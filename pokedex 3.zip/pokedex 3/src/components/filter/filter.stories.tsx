import React from 'react';
import { Meta, StoryFn } from '@storybook/react';
import AppFilter from './filter';
import PokemonProvider from '../../context/pokemonContext/pokemon.provider';

export default {
  title: 'Components/AppFilter',
  component: AppFilter,
  argTypes: {
    isFilterEnable: { action: 'filter enabled' },
  },
  decorators: [(StoryFn)=>(
    <PokemonProvider>
      <StoryFn></StoryFn>
    </PokemonProvider>
  )]
} as Meta;

const Template: StoryFn<{ isFilterEnable: (enabled: boolean) => void }> = (args) => <AppFilter {...args} />;

export const Default = Template.bind({});
Default.args = {
  isFilterEnable: (enabled: boolean) => console.log('Filter enabled:', enabled),
};
