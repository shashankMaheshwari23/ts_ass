import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import "@testing-library/jest-dom";
import AppFilter from "./filter";
import PokemonContext from "../../context/pokemonContext/pokmon.context";
import { cardData } from "../pokemonCard/pokemonCardMock.data";

describe("AppFilter Component", () => {
  const mockIsFilterEnable = jest.fn();
  const mockContextValue = {
    state: {
      allPokemonsList: [cardData],
      pokemonsTypes: [],
      pokemonGenderList: [],
      pokemonsList: [],
      pokemonSelectedId: null,
      pokemonData: null,
      isLoading: false,
      isLoadMoreInprogress: false,
    },
    getPokemonData: jest.fn(),
    dispatch: jest.fn(),
    setAppLoading: jest.fn(),
    getPokemonDetailsListByUrl: jest.fn().mockResolvedValue([]),
  };

  const renderComponent = () =>
    render(
      <PokemonContext.Provider value={mockContextValue}>
        <AppFilter isFilterEnable={mockIsFilterEnable} />
      </PokemonContext.Provider>
    );

  test("renders search input with placeholder", () => {
    renderComponent();
    expect(screen.getByPlaceholderText("Name or Number")).toBeInTheDocument();
  });

  test("calls onSearchChangeHandler on input change", () => {
    renderComponent();
    const inputElement = screen.getByPlaceholderText("Name or Number");
    fireEvent.change(inputElement, { target: { value: "pika" } });
    expect(mockContextValue.setAppLoading).toHaveBeenCalledWith(true);
  });

  test("renders type and gender dropdowns", () => {
    renderComponent();
    expect(screen.getByText("Type")).toBeInTheDocument();
    expect(screen.getByText("Gender")).toBeInTheDocument();
  });
});
