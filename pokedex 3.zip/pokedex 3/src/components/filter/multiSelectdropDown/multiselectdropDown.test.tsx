import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import AppMultiSelectDropDown from './multiSelectdropDown';

describe('AppMultiSelectDropDown Component', () => {
  const mockOnChangeHandler = jest.fn();
  const mockOnOpenHandler = jest.fn();
  const mockOnCloseHandler = jest.fn();
  const mockOnCleanHandler = jest.fn();

  const renderComponent = (props = {}) =>
    render(
      <AppMultiSelectDropDown
        data={[{ label: 'Option 1', value: '1' }, { label: 'Option 2', value: '2' }]}
        placeholder="Select options"
        onChangeHandler={mockOnChangeHandler}
        onOpenHandler={mockOnOpenHandler}
        onCloseHandler={mockOnCloseHandler}
        onCleanHandler={mockOnCleanHandler}
        label="Select Options"
        {...props}
      />
    );

  test('renders label correctly', () => {
    renderComponent();
    expect(screen.getByText('Select Options')).toBeInTheDocument();
  });

  test('calls onChangeHandler when an option is selected', () => {
    renderComponent();
    fireEvent.click(screen.getByText('Select options'));
    fireEvent.click(screen.getByText('Option 1'));
    expect(mockOnChangeHandler).toHaveBeenCalled();
  });
  test('is open class added', () => {
    const {container}=renderComponent({isOpen:true});
    expect(container.querySelector('.is-dropdown-open')).toBeInTheDocument();
  });
});
