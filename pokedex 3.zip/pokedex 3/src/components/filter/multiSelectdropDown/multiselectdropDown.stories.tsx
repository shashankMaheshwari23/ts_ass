import React, { SyntheticEvent } from 'react';
import { Meta, StoryFn } from '@storybook/react';
import AppMultiSelectDropDown from './multiSelectdropDown';

export default {
  title: 'Components/AppMultiSelectDropDown',
  component: AppMultiSelectDropDown,
  argTypes: {
    onChangeHandler: { action: 'changed' },
    onOpenHandler: { action: 'opened' },
    onCloseHandler: { action: 'closed' },
    onCleanHandler: { action: 'cleaned' },
  },
} as Meta;

const Template: StoryFn<{
  data: any[];
  placeholder?: string;
  label?: string;
  isOpen?: boolean;
  onChangeHandler: (value: any, event: SyntheticEvent<Element, Event>) => void;
}> = (args) => <AppMultiSelectDropDown {...args} />;

export const Default = Template.bind({});
Default.args = {
  data: [
    { label: 'Option 1', value: '1' },
    { label: 'Option 2', value: '2' },
    { label: 'Option 3', value: '3' },
  ],
  placeholder: 'Select Options',
  label: 'Example Label',
  isOpen: false,
  onChangeHandler: () => {},
};
