import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import Header from './header';

describe('Header Component', () => {
  test('renders children correctly', () => {
    render(
      <Header>
        <h1>Test Header</h1>
      </Header>
    );

    expect(screen.getByText('Test Header')).toBeInTheDocument();
  });

  test('applies the correct class name', () => {
    render(
      <Header>
        <h1>Test Header</h1>
      </Header>
    );

    const headerElement = screen.getByRole('banner');
    expect(headerElement).toHaveClass('header');
  });
});
