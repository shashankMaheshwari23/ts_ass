import React from 'react';
import { Meta, StoryFn } from '@storybook/react';
import Header from './header';

export default {
  title: 'Components/Header',
  component: Header,
  argTypes: {
    children: { control: 'text' },
  },
} as Meta;

const Template: StoryFn<{ children: React.ReactNode }> = (args) => <Header {...args} />;

export const Default = Template.bind({});
Default.args = {
  children: 'Welcome to the Pokedex',
};

export const CustomContent = Template.bind({});
CustomContent.args = {
  children: <h2>Custom Header Content</h2>,
};
