import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import PokemonCard from './pokemonCard';
import { cardData } from './pokemonCardMock.data';

describe('PokemonCard Component', () => {
  const mockData = cardData;

  const mockOnClick = jest.fn();

  test('renders PokemonCard with correct data', () => {
    render(<PokemonCard data={mockData} onClick={mockOnClick} />);
    
    expect(screen.getByText('bulbasaur')).toBeInTheDocument();
    expect(screen.getByText('001')).toBeInTheDocument(); // Assuming numberFormation formats the id as #025
    expect(screen.getByRole('img')).toHaveAttribute('src', 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/dream-world/1.svg');
  });

  test('calls onClick handler when card is clicked', () => {
    render(<PokemonCard data={mockData} onClick={mockOnClick} />);
    
    const cardElement = screen.getByRole('presentation');
    fireEvent.click(cardElement);
    
    expect(mockOnClick).toHaveBeenCalledTimes(1);
  });

  test('renders placeholder image if no sprite is available', () => {
    const dataWithoutSprite = {
      ...mockData,
      sprites: {
        other: {
          dream_world: {
            front_default: null,
            front_female: null,
          },
        },
        front_default: null,
      },
    };

    render(<PokemonCard data={dataWithoutSprite} onClick={mockOnClick} />);
    
    expect(screen.getByRole('img')).toHaveAttribute('src', 'https://via.placeholder.com/150');
  });
});
