import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import PropertyCard from './propertyCard';

jest.mock('../colorfulTags/colorfulTag', () => ({ type, text }: { type: string; text: string }) => (
  <div>{text}</div>
));

describe('PropertyCard Component', () => {
  const mockSpeciesData = {
    egg_groups: [{ name: 'monster' }],
  };

  const mockData = {
    height: 7,
    weight: 69,
    abilities: [{ ability: { name: 'overgrow' } }, { ability: { name: 'chlorophyll' } }],
    types: [{ type: { name: 'grass' } }, { type: { name: 'poison' } }],
  };

  const mockPokemonTypeData = {
    damage_relations: {
      double_damage_from: [{ name: 'fire' }, { name: 'ice' }],
    },
  };

  test('renders height and weight correctly', () => {
    render(<PropertyCard speciesData={mockSpeciesData} data={mockData} pokemonTypeData={mockPokemonTypeData} />);
    expect(screen.getByText('Height')).toBeInTheDocument();
    expect(screen.getByText('7')).toBeInTheDocument();
    expect(screen.getByText('Weight')).toBeInTheDocument();
    expect(screen.getByText('6.9 Kg')).toBeInTheDocument();
  });

  test('renders egg groups correctly', () => {
    render(<PropertyCard speciesData={mockSpeciesData} data={mockData} pokemonTypeData={mockPokemonTypeData} />);
    expect(screen.getByText('Egg Groups')).toBeInTheDocument();
    expect(screen.getByText('Monster')).toBeInTheDocument();
  });

  test('renders abilities correctly', () => {
    render(<PropertyCard speciesData={mockSpeciesData} data={mockData} pokemonTypeData={mockPokemonTypeData} />);
    expect(screen.getByText('Abilities')).toBeInTheDocument();
    expect(screen.getByText('Overgrow')).toBeInTheDocument();
    expect(screen.getByText('Chlorophyll')).toBeInTheDocument();
  });

  test('renders types correctly', () => {
    render(<PropertyCard speciesData={mockSpeciesData} data={mockData} pokemonTypeData={mockPokemonTypeData} />);
    expect(screen.getByText('Types')).toBeInTheDocument();
    expect(screen.getByText('Grass')).toBeInTheDocument();
    expect(screen.getByText('Poison')).toBeInTheDocument();
  });

  test('renders weaknesses correctly', () => {
    render(<PropertyCard speciesData={mockSpeciesData} data={mockData} pokemonTypeData={mockPokemonTypeData} />);
    expect(screen.getByText('Weak Against')).toBeInTheDocument();
    expect(screen.getByText('Fire')).toBeInTheDocument();
    expect(screen.getByText('Ice')).toBeInTheDocument();
  });
});
