import React from 'react';
import { Meta, StoryFn } from '@storybook/react';
import PropertyCard from './propertyCard';

export default {
  title: 'Components/PropertyCard',
  component: PropertyCard,
  argTypes: {
    speciesData: { control: 'object' },
    data: { control: 'object' },
    pokemonTypeData: { control: 'object' },
  },
} as Meta;

const Template: StoryFn<{
  speciesData: { egg_groups: { name: string }[] };
  data: {
    height: number;
    weight: number;
    abilities: { ability: { name: string } }[];
    types: { type: { name: string } }[];
  };
  pokemonTypeData: {
    damage_relations: {
      double_damage_from: { name: string }[];
    };
  };
}> = (args) => <PropertyCard {...args} />;

export const Default = Template.bind({});
Default.args = {
  speciesData: {
    egg_groups: [{ name: 'monster' }, { name: 'grass' }],
  },
  data: {
    height: 7,
    weight: 69,
    abilities: [{ ability: { name: 'overgrow' } }, { ability: { name: 'chlorophyll' } }],
    types: [{ type: { name: 'grass' } }, { type: { name: 'poison' } }],
  },
  pokemonTypeData: {
    damage_relations: {
      double_damage_from: [{ name: 'fire' }, { name: 'ice' }],
    },
  },
};
