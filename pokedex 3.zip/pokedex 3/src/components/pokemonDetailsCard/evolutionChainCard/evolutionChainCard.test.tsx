import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import EvolutionChainCard from './evolutionChainCard';
import { cardData } from '../../pokemonCard/pokemonCardMock.data';

jest.mock('../../pokemonCard/pokemonCard', () => () => <div>PokemonCard</div>);

describe('EvolutionChainCard Component', () => {
  const mockData = cardData

  test('renders the PokemonCard component for each element in the array', () => {
    render(<EvolutionChainCard data={mockData} />);
    const pokemonCards = screen.getAllByText('PokemonCard');
    expect(pokemonCards).toHaveLength(3);
  });

  test('renders the right arrow icon between PokemonCards', () => {
    render(<EvolutionChainCard data={mockData} />);
    const rightArrowIcons = screen.getAllByAltText('right arrow icon');
    expect(rightArrowIcons).toHaveLength(2);
  });
});
