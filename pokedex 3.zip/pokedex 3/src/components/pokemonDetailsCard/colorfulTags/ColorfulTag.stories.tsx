import React from 'react';
import { Meta, StoryFn } from '@storybook/react';
import ColorfulTag from './colorfulTag';

export default {
  title: 'Components/ColorfulTag',
  component: ColorfulTag,
  argTypes: {
    text: { control: 'text' },
    className: { control: 'text' },
    type: { control: 'text' },
  },
} as Meta;

const Template: StoryFn<{ text: string; className?: string; type: string }> = (args) => <ColorfulTag {...args} />;

export const Default = Template.bind({});
Default.args = {
  text: 'Grass',
  type: 'grass',
  className: 'default-tag',
};

export const FireType = Template.bind({});
FireType.args = {
  text: 'Fire',
  type: 'fire',
  className: 'fire-tag',
};
