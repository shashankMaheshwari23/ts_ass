import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import ColorfulTag from './colorfulTag';

describe('ColorfulTag Component', () => {
  test('renders the text correctly', () => {
    render(<ColorfulTag text="Fire" type="fire" />);
    const tagElement = screen.getByText(/Fire/i);
    expect(tagElement).toBeInTheDocument();
  });

  test('applies the correct background color', () => {
    render(<ColorfulTag text="Fire" type="fire" />);
    const tagElement = screen.getByText(/Fire/i);
    expect(tagElement).toHaveStyle(`background: #EDC2C4`);
  });

  test('applies the provided className', () => {
    render(<ColorfulTag text="Fire" type="fire" className="custom-class" />);
    const containerElement = screen.getByText(/Fire/i).parentElement;
    expect(containerElement).toHaveClass('custom-class');
  });
});
