import React from 'react';
import { Meta, StoryFn } from '@storybook/react';
import StatCard from './statCard';

export default {
  title: 'Components/StatCard',
  component: StatCard,
  argTypes: {
    stats: { control: 'object' },
  },
} as Meta;

const Template: StoryFn<{
  stats: {
    base_stat: number;
    stat: {
      name: string;
    };
  }[];
}> = (args) => <StatCard {...args} />;

export const Default = Template.bind({});
Default.args = {
  stats: [
    { base_stat: 45, stat: { name: 'hp' } },
    { base_stat: 60, stat: { name: 'attack' } },
    { base_stat: 48, stat: { name: 'defense' } },
    { base_stat: 65, stat: { name: 'special-attack' } },
    { base_stat: 65, stat: { name: 'special-defense' } },
    { base_stat: 45, stat: { name: 'speed' } },
  ],
};
