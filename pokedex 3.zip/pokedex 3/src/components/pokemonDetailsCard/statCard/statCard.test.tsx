import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import StatCard from './statCard';

import { getCamleCaseString } from '../../../constants/pokemon.types';

describe('StatCard Component', () => {
  const mockStats = [
    { base_stat: 45, stat: { name: 'hp' } },
    { base_stat: 60, stat: { name: 'attack' } },
    { base_stat: 48, stat: { name: 'defense' } },
    { base_stat: 65, stat: { name: 'special-attack' } },
    { base_stat: 65, stat: { name: 'special-defense' } },
    { base_stat: 42, stat: { name: 'speed' } },
  ];

  test('renders the stat header', () => {
    render(<StatCard stats={mockStats} />);
    expect(screen.getByText('Stats')).toBeInTheDocument();
  });

  test('renders each stat with correct heading and value', () => {
    render(<StatCard stats={mockStats} />);
    mockStats.forEach(stat => {
      const heading = stat.stat.name === 'hp' ? 'HP' : stat.stat.name.split('-').map((name)=>{;
            if (name === "special") {
              return "Sp."
            } else {
              return getCamleCaseString(name);
            }}).join(' ');
      expect(screen.getByText(heading)).toBeInTheDocument();
      expect(screen.getAllByText(stat.base_stat.toString())[0]).toBeInTheDocument();
    });
  });

  test('renders progress bars for each stat', () => {
    render(<StatCard stats={mockStats} />);
    const progressBars = screen.getAllByRole('progressbar');
    expect(progressBars).toHaveLength(mockStats.length);
    progressBars.forEach((progressBar, index) => {
      expect(progressBar).toHaveAttribute('value', mockStats[index].base_stat.toString());
    });
  });
});
