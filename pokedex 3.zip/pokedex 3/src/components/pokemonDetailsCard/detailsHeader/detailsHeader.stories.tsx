import React from 'react';
import { Meta, StoryFn } from '@storybook/react';
import DetailsHeader from './detailsHeader';

export default {
  title: 'Components/DetailsHeader',
  component: DetailsHeader,
  argTypes: {
    data: { control: 'object' },
    speciesData: { control: 'object' },
    backClick: { action: 'backClick' },
    closeClick: { action: 'closeClick' },
    forwordClick: { action: 'forwordClick' },
  },
} as Meta;

const Template: StoryFn<{
  data: { id: number; name: string };
  speciesData: { flavor_text_entries?: any[] };
  backClick: () => void;
  closeClick: () => void;
  forwordClick: () => void;
}> = (args) => <DetailsHeader {...args} />;

export const Default = Template.bind({});
Default.args = {
  data: {
    id: 1,
    name: 'Bulbasaur',
  },
  speciesData: {
    flavor_text_entries: [
        {
            "flavor_text": "A strange seed was\nplanted on its\nback at birth.\fThe plant sprouts\nand grows with\nthis POKéMON.",
            "language": {
              "name": "en",
              "url": "https://pokeapi.co/api/v2/language/9/"
            },
            "version": {
              "name": "red",
              "url": "https://pokeapi.co/api/v2/version/1/"
            }
          },
    ],
  },
};
