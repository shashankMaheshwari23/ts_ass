import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import DetailsHeader from './detailsHeader';

jest.mock('../../pokemonCard/pokemonCard', () => () => <div>PokemonCard</div>);
jest.mock('../../../hooks/tooltip/tooltip', () => () => <div>AppTooltip</div>);

describe('DetailsHeader Component', () => {
  const mockData = {
    id: 1,
    name: 'Bulbasaur',
  };

  const mockSpeciesData = {
    flavor_text_entries: [
        {
            "flavor_text": "A strange seed was\nplanted on its\nback at birth.\fThe plant sprouts\nand grows with\nthis POKéMON.",
            "language": {
              "name": "en",
              "url": "https://pokeapi.co/api/v2/language/9/"
            },
            "version": {
              "name": "red",
              "url": "https://pokeapi.co/api/v2/version/1/"
            }
          },
    ],
  };

  const mockBackClick = jest.fn();
  const mockCloseClick = jest.fn();
  const mockForwordClick = jest.fn();

  test('renders the Pokemon name and ID correctly', () => {
    render(
      <DetailsHeader
        data={mockData}
        speciesData={mockSpeciesData}
        backClick={mockBackClick}
        closeClick={mockCloseClick}
        forwordClick={mockForwordClick}
      />
    );

    expect(screen.getByText(/Bulbasaur/i)).toBeInTheDocument();
    expect(screen.getByText(/001/i)).toBeInTheDocument();
  });

  test('calls backClick when the back icon is clicked', () => {
    render(
      <DetailsHeader
        data={mockData}
        speciesData={mockSpeciesData}
        backClick={mockBackClick}
        closeClick={mockCloseClick}
        forwordClick={mockForwordClick}
      />
    );

    const backIcon = screen.getByAltText('back icon to go backward');
    fireEvent.click(backIcon);
    expect(mockBackClick).toHaveBeenCalledTimes(1);
  });

  test('calls closeClick when the close icon is clicked', () => {
    render(
      <DetailsHeader
        data={mockData}
        speciesData={mockSpeciesData}
        backClick={mockBackClick}
        closeClick={mockCloseClick}
        forwordClick={mockForwordClick}
      />
    );

    const closeIcon = screen.getByAltText('close icon to go backward');
    fireEvent.click(closeIcon);
    expect(mockCloseClick).toHaveBeenCalledTimes(1);
  });

  test('calls forwordClick when the forward icon is clicked', () => {
    render(
      <DetailsHeader
        data={mockData}
        speciesData={mockSpeciesData}
        backClick={mockBackClick}
        closeClick={mockCloseClick}
        forwordClick={mockForwordClick}
      />
    );

    const forwardIcon = screen.getByAltText('forward icon to go backward');
    fireEvent.click(forwardIcon);
    expect(mockForwordClick).toHaveBeenCalledTimes(1);
  });
});
