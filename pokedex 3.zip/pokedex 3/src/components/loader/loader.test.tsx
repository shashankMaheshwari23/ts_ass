import React from 'react';
import { render, screen } from '@testing-library/react';
import '@testing-library/jest-dom';
import Apploader from './loader';

describe('Apploader Component', () => {
  test('renders loader with default content', () => {
    render(<Apploader />);
    
    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  test('applies custom className', () => {
    const customClass = 'custom-loader-class';
    render(<Apploader className={customClass} />);
    
    const loaderElement = screen.getByText('Loading...');
    expect(loaderElement).toBeInTheDocument();
  });
});
