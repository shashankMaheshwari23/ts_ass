import React from 'react';
import { Meta, StoryFn } from '@storybook/react';
import Apploader from './loader';

export default {
  title: 'Components/Apploader',
  component: Apploader,
  argTypes: {
    className: { control: 'text' },
  },
} as Meta;

const Template: StoryFn<{ className?: string }> = (args) => <Apploader {...args} />;

export const Default = Template.bind({});
Default.args = {
  className: 'default-loader',
};

export const CustomClass = Template.bind({});
CustomClass.args = {
  className: 'loadmore-loader',
};
