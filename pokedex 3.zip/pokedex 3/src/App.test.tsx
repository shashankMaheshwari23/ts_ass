// App.test.tsx
import React from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import App from './App';

jest.mock('./pages/home/home.page', () => () => <div>Home Page</div>);
jest.mock('./pages/details/details.page', () => () => <div>Detail Page</div>);

jest.mock('./context/pokemonContext/pokemon.provider', () => ({
  __esModule: true,
  default: ({ children }: { children: React.ReactNode }) => (
    <div data-testid="mock-provider">{children}</div>
  ),
}));


describe('App Router', () => {
  test('renders home page', async () => {
    render(<App />);
    await waitFor(() => {
      expect(screen.getByText('Home Page')).toBeInTheDocument();
    });
  });
});
