import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import '@testing-library/jest-dom';
import AppTooltip from './tooltip';

describe('AppTooltip Component', () => {
  const renderComponent = (props = {}) =>
    render(
      <AppTooltip
        placement="top"
        data="Tooltip Content"
        className="tooltip-class"
        name="Hover me"
        tooltipClass="popover-class"
        {...props}
      />
    );

  test('renders tooltip trigger with correct name', () => {
    renderComponent();
    expect(screen.getByText('Hover me')).toBeInTheDocument();
  });

  test('displays tooltip content on click', () => {
    renderComponent();
    const triggerElement = screen.getByText('Hover me');
    fireEvent.click(triggerElement);
    expect(screen.getByText('Tooltip Content')).toBeInTheDocument();
  });

  test('applies custom class to tooltip trigger', () => {
    renderComponent();
    const triggerElement = screen.getByText('Hover me');
    expect(triggerElement).toHaveClass('tooltip-class');
  });
});
