import React from 'react';
import { Meta, StoryFn } from '@storybook/react';
import AppTooltip from './tooltip';

// Default export to define the component's metadata
export default {
  title: 'Components/AppTooltip',
  component: AppTooltip,
  argTypes: {
    placement: {
      control: {
        type: 'select',
        options: ['top', 'bottom', 'left', 'right'],
      },
    },
    data: { control: 'text' },
    className: { control: 'text' },
    name: { control: 'text' },
    tooltipClass: { control: 'text' },
  },
} as Meta<typeof AppTooltip>;

// Template for creating stories
const Template: StoryFn<typeof AppTooltip> = (args) => <AppTooltip {...args} />;

// Default story
export const Default = Template.bind({});
Default.args = {
  placement: 'top',
  data: 'This is a tooltip',
  className: 'example-class',
  name: 'Hover over me',
  tooltipClass: 'tooltip-class',
};

// Additional stories can be added here
