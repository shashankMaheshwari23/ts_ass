import { getPokemonData, getSpeciesDataById, getPokemonTypesById, getPokemonTypes, getPokemonGenders, getPokemonDataById, getPokemonDataByURL, numberFormation, getAllParallelCall, removeDuplicateBy } from './common.service';

global.fetch = jest.fn();

describe('Common Service', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should fetch pokemon data', async () => {
    const mockData = { results: [{ name: 'Bulbasaur', url: 'https://pokeapi.co/api/v2/pokemon/1/' }] };
    (fetch as jest.Mock).mockResolvedValueOnce({
      json: jest.fn().mockResolvedValueOnce(mockData),
    });

    const data = await getPokemonData();
    expect(data).toEqual(mockData);
    expect(fetch).toHaveBeenCalledWith(expect.stringContaining('/pokemon?limit='));
  });

  it('should fetch species data by ID', async () => {
    const mockData = { gender_rate: 1, habitat: { name: 'forest' } };
    (fetch as jest.Mock).mockResolvedValueOnce({
      json: jest.fn().mockResolvedValueOnce(mockData),
    });

    const data = await getSpeciesDataById(1);
    expect(data).toEqual(mockData);
    expect(fetch).toHaveBeenCalledWith(expect.stringContaining('/pokemon-species/1/'));
  });

  it('should format numbers correctly', () => {
    expect(numberFormation(1)).toBe('001');
    expect(numberFormation(10)).toBe('010');
    expect(numberFormation(100)).toBe('100');
  });

  it('should remove duplicates by property', () => {
    const data = [
      { id: 1, name: 'Bulbasaur' },
      { id: 2, name: 'Ivysaur' },
      { id: 1, name: 'Bulbasaur' }
    ];
    const result = removeDuplicateBy(data, 'id');
    expect(result).toEqual([{ id: 1, name: 'Bulbasaur' }, { id: 2, name: 'Ivysaur' }]);
  });

  // Add more test cases for other functions as needed
});
