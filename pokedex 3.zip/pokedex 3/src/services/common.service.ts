import { LIMIT, baseURL } from "../constants/apiUrls";
import { Pokemon as PokemonType } from "../store/reducers/reducer";

// API URLs
export const initialURL = `${baseURL}/pokemon?limit=${LIMIT}`;
export const allPokemonURL = `${baseURL}/pokemon?limit=1100`;

// Basic interfaces (extend as needed)
export interface PokemonSummary {
  name: string;
  url: string;
}

export interface Pokemon extends PokemonType {
  id: number;
  name: string;
  [key: string]: any; // use a stricter type if possible
}

export interface Species {
  gender_rate: number;
  habitat: { name: string };
  [key: string]: any;
}

export interface Type {
  name: string;
  [key: string]: any;
}

export interface Gender {
  name: string;
  [key: string]: any;
}

// API Functions
export const getPokemonData = async (): Promise<{ results: PokemonSummary[] }> => {
  const response = await fetch(initialURL);
  return await response.json();
};

export const getSpeciesDataById = async (id: number | string): Promise<Species> => {
  const response = await fetch(`${baseURL}/pokemon-species/${id}/`);
  return await response.json();
};

export const getPokemonTypesById = async (id: number | string): Promise<Type> => {
  const response = await fetch(`${baseURL}/type/${id}/`);
  return await response.json();
};

export const getPokemonTypes = async (): Promise<{ results: Type[] }> => {
  const response = await fetch(`${baseURL}/type`);
  return await response.json();
};

export const getPokemonGenders = async (): Promise<{ results: Gender[] }> => {
  const response = await fetch(`${baseURL}/gender`);
  return await response.json();
};

export const getPokemonDataById = async (id: number | string): Promise<Pokemon> => {
  const response = await fetch(`${baseURL}/pokemon/${id}/`);
  return await response.json();
};

export const getPokemonDataByURL = async (url: string): Promise<Pokemon> => {
  const response = await fetch(url);
  return await response.json();
};

export const numberFormation = (number: number): string => {
  if (number < 10) return `00${number}`;
  if (number >= 10 && number < 100) return `0${number}`;
  return `${number}`;
};

export const getAllParallelCall = async (apiUrls: string[]): Promise<any[]> => {
  return await Promise.all(apiUrls.map(async (url) => {
    const res = await fetch(url);
    return await res.json();
  }));
};

export const removeDuplicateBy = <T>(arr: T[], prop: keyof T): T[] => {
  return [...new Map(arr.map((item) => [item[prop], item])).values()];
};
